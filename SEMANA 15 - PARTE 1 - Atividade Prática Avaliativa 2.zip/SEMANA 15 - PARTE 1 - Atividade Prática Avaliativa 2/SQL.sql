-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS sistemaFaculdade DEFAULT CHARACTER SET utf8 ;
USE sistemaFaculdade ;

-- -----------------------------------------------------
-- Table `mydb`.`Professores`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Professores` (
  `idProfessores` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NOT NULL,
  `CPF` INT NOT NULL,
  `titulacaoMax` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idProfessores`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Disciplinas`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Disciplinas` (
  `idDisciplinas` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idDisciplinas`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Periodo`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Periodo` (
  `idPeriodo` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NOT NULL,
  `Disciplinas_idDisciplinas` INT NOT NULL,
  PRIMARY KEY (`idPeriodo`, `Disciplinas_idDisciplinas`),
  INDEX `fk_Periodo_Disciplinas1_idx` (`Disciplinas_idDisciplinas` ASC) ,
  CONSTRAINT `fk_Periodo_Disciplinas1`
    FOREIGN KEY (`Disciplinas_idDisciplinas`)
    REFERENCES `mydb`.`Disciplinas` (`idDisciplinas`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Curso`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Curso` (
  `idCurso` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NOT NULL,
  `Periodo_idPeriodo` INT NOT NULL,
  PRIMARY KEY (`idCurso`, `Periodo_idPeriodo`),
  INDEX `fk_Curso_Periodo1_idx` (`Periodo_idPeriodo` ASC) ,
  CONSTRAINT `fk_Curso_Periodo1`
    FOREIGN KEY (`Periodo_idPeriodo`)
    REFERENCES `mydb`.`Periodo` (`idPeriodo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Alunos`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Alunos` (
  `idAlunos` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NOT NULL,
  `matricula` INT NOT NULL,
  `dataNasc` DATE NOT NULL,
  `Curso_idCurso` INT NOT NULL,
  `Curso_Periodo_idPeriodo` INT NOT NULL,
  PRIMARY KEY (`idAlunos`, `Curso_idCurso`, `Curso_Periodo_idPeriodo`),
  INDEX `fk_Alunos_Curso1_idx` (`Curso_idCurso` ASC, `Curso_Periodo_idPeriodo` ASC) ,
  CONSTRAINT `fk_Alunos_Curso1`
    FOREIGN KEY (`Curso_idCurso` , `Curso_Periodo_idPeriodo`)
    REFERENCES `mydb`.`Curso` (`idCurso` , `Periodo_idPeriodo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Disciplinas_has_Professores`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Disciplinas_has_Professores` (
  `Disciplinas_idDisciplinas` INT NOT NULL,
  `Professores_idProfessores` INT NOT NULL,
  PRIMARY KEY (`Disciplinas_idDisciplinas`, `Professores_idProfessores`),
  INDEX `fk_Disciplinas_has_Professores_Professores1_idx` (`Professores_idProfessores` ASC) ,
  INDEX `fk_Disciplinas_has_Professores_Disciplinas_idx` (`Disciplinas_idDisciplinas` ASC) ,
  CONSTRAINT `fk_Disciplinas_has_Professores_Disciplinas`
    FOREIGN KEY (`Disciplinas_idDisciplinas`)
    REFERENCES `mydb`.`Disciplinas` (`idDisciplinas`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Disciplinas_has_Professores_Professores1`
    FOREIGN KEY (`Professores_idProfessores`)
    REFERENCES `mydb`.`Professores` (`idProfessores`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Disciplinas_has_Curso`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Disciplinas_has_Curso` (
  `Disciplinas_idDisciplinas` INT NOT NULL,
  `Curso_idCurso` INT NOT NULL,
  PRIMARY KEY (`Disciplinas_idDisciplinas`, `Curso_idCurso`),
  INDEX `fk_Disciplinas_has_Curso_Curso1_idx` (`Curso_idCurso` ASC) ,
  INDEX `fk_Disciplinas_has_Curso_Disciplinas1_idx` (`Disciplinas_idDisciplinas` ASC) ,
  CONSTRAINT `fk_Disciplinas_has_Curso_Disciplinas1`
    FOREIGN KEY (`Disciplinas_idDisciplinas`)
    REFERENCES `mydb`.`Disciplinas` (`idDisciplinas`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Disciplinas_has_Curso_Curso1`
    FOREIGN KEY (`Curso_idCurso`)
    REFERENCES `mydb`.`Curso` (`idCurso`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Alunos_has_Disciplinas`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Alunos_has_Disciplinas` (
  `Alunos_idAlunos` INT NOT NULL,
  `Disciplinas_idDisciplinas` INT NOT NULL,
  PRIMARY KEY (`Alunos_idAlunos`, `Disciplinas_idDisciplinas`),
  INDEX `fk_Alunos_has_Disciplinas_Disciplinas1_idx` (`Disciplinas_idDisciplinas` ASC) ,
  INDEX `fk_Alunos_has_Disciplinas_Alunos1_idx` (`Alunos_idAlunos` ASC) ,
  CONSTRAINT `fk_Alunos_has_Disciplinas_Alunos1`
    FOREIGN KEY (`Alunos_idAlunos`)
    REFERENCES `mydb`.`Alunos` (`idAlunos`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Alunos_has_Disciplinas_Disciplinas1`
    FOREIGN KEY (`Disciplinas_idDisciplinas`)
    REFERENCES `mydb`.`Disciplinas` (`idDisciplinas`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
